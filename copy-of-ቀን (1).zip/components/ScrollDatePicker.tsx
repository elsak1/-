
import React, { useRef, useEffect, useState } from 'react';

interface ScrollDatePickerProps {
  selectedDate: string; // YYYY-MM-DD
  onSelect: (date: string) => void;
  label: string;
}

const ScrollDatePicker: React.FC<ScrollDatePickerProps> = ({ selectedDate, onSelect, label }) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const itemHeight = 64; // h-16 = 64px

  // Generate 90 days from today
  const dates = Array.from({ length: 90 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i);
    return d.toISOString().split('T')[0];
  });

  const handleScroll = () => {
    if (!scrollRef.current) return;
    const scrollTop = scrollRef.current.scrollTop;
    const index = Math.round(scrollTop / itemHeight);
    const date = dates[index];
    if (date && date !== selectedDate) {
      onSelect(date);
    }
  };

  useEffect(() => {
    if (scrollRef.current) {
      const index = dates.indexOf(selectedDate);
      if (index !== -1) {
        scrollRef.current.scrollTop = index * itemHeight;
      }
    }
  }, []); // Only on mount to sync initial position

  return (
    <div className="space-y-3">
      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">{label}</label>
      <div className="relative h-48 bg-gray-50 rounded-[32px] overflow-hidden border-2 border-transparent hover:border-indigo-100 transition-all">
        {/* Selection Highlight */}
        <div className="absolute top-1/2 left-4 right-4 h-14 -translate-y-1/2 bg-indigo-600 rounded-2xl shadow-xl shadow-indigo-200 z-0 pointer-events-none transition-all"></div>
        
        {/* Wheel Gradients */}
        <div className="absolute top-0 left-0 right-0 h-16 bg-gradient-to-b from-gray-50 to-transparent z-10 pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-gray-50 to-transparent z-10 pointer-events-none"></div>

        <div 
          ref={scrollRef}
          onScroll={handleScroll}
          className="h-full overflow-y-auto no-scrollbar snap-y snap-mandatory relative z-20"
        >
          {/* Top and Bottom Padding to allow first/last items to center */}
          <div className="h-16" /> 
          
          {dates.map((date) => {
            const d = new Date(date + 'T12:00:00');
            const isSelected = selectedDate === date;
            const dayName = d.toLocaleDateString(undefined, { weekday: 'short' });
            const monthName = d.toLocaleDateString(undefined, { month: 'short' });
            const dayNum = d.getDate();

            return (
              <div
                key={date}
                className="h-16 flex items-center justify-center snap-center cursor-pointer"
                onClick={() => {
                  const index = dates.indexOf(date);
                  if (scrollRef.current) scrollRef.current.scrollTo({ top: index * itemHeight, behavior: 'smooth' });
                }}
              >
                <div className={`flex items-center gap-4 transition-all duration-300 ${
                  isSelected ? 'text-white scale-110' : 'text-gray-400 opacity-40 scale-90 blur-[0.5px]'
                }`}>
                  <div className="flex flex-col items-center">
                    <span className="text-[10px] font-black uppercase leading-none">{monthName}</span>
                    <span className="text-xl font-black">{dayNum}</span>
                  </div>
                  <div className="w-[1px] h-6 bg-current opacity-30"></div>
                  <span className="text-sm font-bold uppercase tracking-widest">{dayName}</span>
                </div>
              </div>
            );
          })}
          
          <div className="h-16" />
        </div>
      </div>
    </div>
  );
};

export default ScrollDatePicker;
