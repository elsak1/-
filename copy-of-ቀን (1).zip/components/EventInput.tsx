
import React, { useState } from 'react';
import { Send, Loader2 } from 'lucide-react';

interface EventInputProps {
  onAdd: (text: string) => Promise<void>;
}

const EventInput: React.FC<EventInputProps> = ({ onAdd }) => {
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    setIsLoading(true);
    await onAdd(input);
    setInput('');
    setIsLoading(false);
  };

  return (
    <form onSubmit={handleSubmit} className="relative group">
      <textarea
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="e.g., 'Team meeting next Tuesday at 3pm for 45 mins at Conference Room B'"
        className="w-full h-32 p-4 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all resize-none text-gray-800 placeholder:text-gray-400"
      />
      <div className="absolute bottom-3 right-3 flex items-center gap-2">
        <span className="text-xs text-gray-400 hidden sm:inline-block">Paste text or type naturally</span>
        <button
          type="submit"
          disabled={!input.trim() || isLoading}
          className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-300 text-white px-4 py-2 rounded-lg font-medium flex items-center gap-2 transition-colors"
        >
          {isLoading ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Send className="w-4 h-4" />
          )}
          {isLoading ? 'Parsing...' : 'Analyze'}
        </button>
      </div>
    </form>
  );
};

export default EventInput;
