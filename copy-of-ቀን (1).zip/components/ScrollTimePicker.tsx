
import React, { useRef, useEffect } from 'react';

interface ScrollTimePickerProps {
  time: string; // HH:mm
  onChange: (time: string) => void;
  label: string;
}

const ScrollTimePicker: React.FC<ScrollTimePickerProps> = ({ time, onChange, label }) => {
  const [hours, minutes] = time.split(':').map(Number);
  const hoursRef = useRef<HTMLDivElement>(null);
  const minutesRef = useRef<HTMLDivElement>(null);
  const itemHeight = 48; // h-12 = 48px

  const hourList = Array.from({ length: 24 }, (_, i) => i);
  const minuteList = Array.from({ length: 60 }, (_, i) => i);

  const handleHourScroll = () => {
    if (!hoursRef.current) return;
    const index = Math.round(hoursRef.current.scrollTop / itemHeight);
    const h = hourList[index];
    if (h !== undefined && h !== hours) {
      onChange(`${h.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`);
    }
  };

  const handleMinuteScroll = () => {
    if (!minutesRef.current) return;
    const index = Math.round(minutesRef.current.scrollTop / itemHeight);
    const m = minuteList[index];
    if (m !== undefined && m !== minutes) {
      onChange(`${hours.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`);
    }
  };

  useEffect(() => {
    if (hoursRef.current) hoursRef.current.scrollTop = hours * itemHeight;
    if (minutesRef.current) minutesRef.current.scrollTop = minutes * itemHeight;
  }, []); // On mount sync

  return (
    <div className="space-y-3">
      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">{label}</label>
      <div className="relative h-40 bg-gray-50 rounded-[32px] overflow-hidden group border-2 border-transparent hover:border-indigo-100 transition-all">
        {/* Highlight Overlay */}
        <div className="absolute top-1/2 left-4 right-4 h-12 -translate-y-1/2 bg-indigo-600/10 rounded-2xl z-0 pointer-events-none"></div>
        
        {/* Wheel Gradients */}
        <div className="absolute top-0 left-0 right-0 h-12 bg-gradient-to-b from-gray-50 to-transparent z-10 pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-gray-50 to-transparent z-10 pointer-events-none"></div>
        
        <div className="flex gap-2 justify-center items-center h-full relative z-20">
          {/* Hours Wheel */}
          <div 
            ref={hoursRef}
            onScroll={handleHourScroll}
            className="h-full overflow-y-auto no-scrollbar snap-y snap-mandatory w-20 text-center"
          >
            <div className="h-12" />
            {hourList.map(h => (
              <div
                key={h}
                className={`h-12 flex items-center justify-center snap-center cursor-pointer transition-all duration-200 ${
                  hours === h ? 'text-3xl font-black text-indigo-600' : 'text-xl font-bold text-gray-300 opacity-40 blur-[0.5px]'
                }`}
                onClick={() => hoursRef.current?.scrollTo({ top: h * itemHeight, behavior: 'smooth' })}
              >
                {h.toString().padStart(2, '0')}
              </div>
            ))}
            <div className="h-12" />
          </div>

          <div className="text-3xl font-black text-indigo-200 mb-1">:</div>

          {/* Minutes Wheel */}
          <div 
            ref={minutesRef}
            onScroll={handleMinuteScroll}
            className="h-full overflow-y-auto no-scrollbar snap-y snap-mandatory w-20 text-center"
          >
            <div className="h-12" />
            {minuteList.map(m => (
              <div
                key={m}
                className={`h-12 flex items-center justify-center snap-center cursor-pointer transition-all duration-200 ${
                  minutes === m ? 'text-3xl font-black text-indigo-600' : 'text-xl font-bold text-gray-300 opacity-40 blur-[0.5px]'
                }`}
                onClick={() => minutesRef.current?.scrollTo({ top: m * itemHeight, behavior: 'smooth' })}
              >
                {m.toString().padStart(2, '0')}
              </div>
            ))}
            <div className="h-12" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScrollTimePicker;
