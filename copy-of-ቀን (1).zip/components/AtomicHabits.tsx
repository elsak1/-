
import React from 'react';
import { Zap, CheckCircle2, Circle, Flame, Trash2, Calendar, TrendingUp, Pause, Play, Clock, Edit3, Infinity as InfinityIcon } from 'lucide-react';
import { Habit, Priority } from '../types';

interface AtomicHabitsProps {
  habits: Habit[];
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onTogglePause: (id: string) => void;
  onEdit: (habit: Habit) => void;
}

const AtomicHabits: React.FC<AtomicHabitsProps> = ({ habits, onToggle, onDelete, onTogglePause, onEdit }) => {
  const todayKey = new Date().toISOString().split('T')[0];
  
  const completionRate = habits.length > 0 
    ? Math.round((habits.filter(h => h.history[todayKey]).length / habits.length) * 100) 
    : 0;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-indigo-600 p-8 rounded-[40px] text-white shadow-xl shadow-indigo-100">
          <TrendingUp className="w-8 h-8 mb-4 opacity-50" />
          <p className="text-4xl font-black tracking-tighter">{completionRate}%</p>
          <p className="text-[10px] font-black uppercase tracking-widest opacity-60">Today's Discipline</p>
        </div>
        <div className="bg-white p-8 rounded-[40px] border border-gray-100 shadow-sm">
          <Flame className="w-8 h-8 mb-4 text-amber-500 opacity-50" />
          <p className="text-4xl font-black text-gray-800 tracking-tighter">
            {habits.reduce((acc, h) => acc + (h.streak || 0), 0)}
          </p>
          <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Global Streaks</p>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest px-4">Atomic Commitments</h3>
        {habits.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-[48px] border border-dashed border-gray-200">
            <Zap className="w-12 h-12 text-gray-200 mx-auto mb-4" />
            <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">Build your first habit</p>
          </div>
        ) : (
          habits.map((habit) => {
            const isEveryDay = habit.frequency === 'daily';
            const isCompletedToday = !!habit.history[todayKey];
            
            return (
              <div 
                key={habit.id}
                className={`group bg-white p-6 rounded-[32px] border transition-all flex items-center justify-between ${
                  isCompletedToday ? 'border-green-100 bg-green-50/30' : 'border-gray-100 hover:border-indigo-100'
                } ${habit.isPaused ? 'opacity-40' : ''}`}
              >
                <div className="flex items-center gap-5">
                  <button 
                    disabled={habit.isPaused}
                    onClick={() => onToggle(habit.id)}
                    className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${
                      isCompletedToday 
                        ? 'bg-green-500 text-white shadow-lg shadow-green-100 scale-110' 
                        : habit.isPaused ? 'bg-gray-200 text-gray-400' : 'bg-gray-50 text-gray-300 hover:text-indigo-400'
                    }`}
                  >
                    {isCompletedToday ? <CheckCircle2 className="w-8 h-8" /> : <Circle className="w-8 h-8" />}
                  </button>
                  
                  <div>
                    <h4 className={`font-black text-lg transition-all ${isCompletedToday ? 'text-green-800 line-through opacity-60' : 'text-gray-800'}`}>
                      {habit.title}
                    </h4>
                    <div className="flex flex-wrap items-center gap-3 mt-1">
                      <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full flex items-center gap-1 ${isEveryDay ? 'bg-amber-50 text-amber-600' : 'bg-indigo-50 text-indigo-600'}`}>
                        {isEveryDay && <InfinityIcon className="w-3 h-3" />}
                        {isEveryDay ? 'Every Day' : habit.frequency}
                      </span>
                      <span className="flex items-center gap-1 text-[11px] text-gray-400 font-black">
                        <Clock className="w-3 h-3 text-indigo-400" />
                        {habit.startTime}
                      </span>
                      <span className="flex items-center gap-1 text-[11px] text-gray-400 font-black">
                        <Flame className="w-3 h-3 text-amber-500" />
                        {habit.streak || 0}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button 
                    onClick={() => onEdit(habit)}
                    className="p-3 text-gray-300 hover:text-indigo-600 hover:bg-indigo-50 rounded-2xl transition-all"
                  >
                    <Edit3 className="w-5 h-5" />
                  </button>
                  <button 
                    onClick={() => onTogglePause(habit.id)}
                    className="p-3 text-gray-300 hover:text-amber-500 hover:bg-amber-50 rounded-2xl transition-all"
                  >
                    {habit.isPaused ? <Play className="w-5 h-5" /> : <Pause className="w-5 h-5" />}
                  </button>
                  <button 
                    onClick={() => onDelete(habit.id)}
                    className="p-3 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-2xl transition-all"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default AtomicHabits;
