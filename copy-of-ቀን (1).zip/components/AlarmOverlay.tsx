
import React, { useState } from 'react';
import { VolumeX, Clock, BellRing, Mic, CheckCircle } from 'lucide-react';
import { CalendarEvent } from '../types';

interface AlarmOverlayProps {
  event: any; // Can be CalendarEvent or Habit
  onDismiss: () => void;
  onSnooze: (minutes: number) => void;
  dismissalPhrase: string;
}

const AlarmOverlay: React.FC<AlarmOverlayProps> = ({ event, onDismiss, onSnooze, dismissalPhrase }) => {
  const [userInput, setUserInput] = useState('');
  const [isError, setIsError] = useState(false);

  const isCorrect = userInput.trim().toLowerCase() === dismissalPhrase.trim().toLowerCase();

  const handleDismiss = () => {
    if (isCorrect) {
      onDismiss();
    } else {
      setIsError(true);
      setTimeout(() => setIsError(false), 500); // Shake animation reset
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-red-600 flex flex-col items-center justify-center p-8 text-white animate-pulse-bg overflow-y-auto">
      <style>{`
        @keyframes pulse-bg {
          0%, 100% { background-color: #dc2626; }
          50% { background-color: #991b1b; }
        }
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-10px); }
          75% { transform: translateX(10px); }
        }
        .shake { animation: shake 0.2s ease-in-out 0s 2; }
      `}</style>
      
      <div className="mb-8 animate-bounce">
        <div className="bg-white/20 p-8 rounded-full">
          <BellRing className="w-16 h-16 text-white" />
        </div>
      </div>

      <div className="text-center space-y-4 max-w-2xl mb-12">
        <h2 className="text-4xl md:text-6xl font-black tracking-tighter uppercase italic">Mandatory Action!</h2>
        <p className="text-2xl md:text-3xl font-light opacity-90">{event.title}</p>
        {event.startTime && (
          <div className="flex items-center justify-center gap-2 text-xl opacity-75">
            <Clock className="w-6 h-6" />
            <span>{typeof event.startTime === 'string' && event.startTime.includes('T') 
              ? new Date(event.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
              : event.startTime}</span>
          </div>
        )}
      </div>

      <div className="w-full max-w-md space-y-6">
        <div className={`space-y-2 ${isError ? 'shake' : ''}`}>
          <label className="text-xs font-black uppercase tracking-widest opacity-70 block text-center">
            Type phrase to dismiss: "{dismissalPhrase}"
          </label>
          <div className="relative">
            <input
              autoFocus
              value={userInput}
              onChange={(e) => {
                setUserInput(e.target.value);
                if (isError) setIsError(false);
              }}
              onKeyDown={(e) => e.key === 'Enter' && handleDismiss()}
              placeholder="Confirm completion..."
              className={`w-full py-5 px-6 rounded-2xl text-2xl font-bold bg-white/10 border-2 transition-all outline-none placeholder:text-white/30 text-center ${
                isCorrect 
                  ? 'border-green-400 bg-green-500/20 text-white' 
                  : isError ? 'border-red-400 bg-red-800/40' : 'border-white/30 focus:border-white'
              }`}
            />
            <div className="absolute right-4 top-1/2 -translate-y-1/2 text-white/50">
              <Mic className="w-6 h-6 cursor-pointer hover:text-white transition-colors" />
            </div>
          </div>
        </div>

        <button
          onClick={handleDismiss}
          className={`w-full py-6 rounded-2xl text-2xl font-black shadow-2xl flex items-center justify-center gap-3 transition-all active:scale-95 ${
            isCorrect 
              ? 'bg-white text-green-600' 
              : 'bg-white/20 text-white opacity-50 cursor-not-allowed'
          }`}
        >
          {isCorrect ? <CheckCircle className="w-8 h-8" /> : <VolumeX className="w-8 h-8" />}
          {isCorrect ? 'COMPLETED' : 'ENTER PHRASE'}
        </button>

        <div className="grid grid-cols-3 gap-4">
          <button
            onClick={() => onSnooze(5)}
            className="py-4 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl border border-white/20 backdrop-blur-md transition-transform"
          >
            5m Snooze
          </button>
          <button
            onClick={() => onSnooze(10)}
            className="py-4 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl border border-white/20 backdrop-blur-md transition-transform"
          >
            10m Snooze
          </button>
          <button
            onClick={() => onSnooze(15)}
            className="py-4 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl border border-white/20 backdrop-blur-md transition-transform"
          >
            15m Snooze
          </button>
        </div>
      </div>

      {event.location && (
        <p className="mt-8 text-white/60 font-medium italic">Location: {event.location}</p>
      )}
    </div>
  );
};

export default AlarmOverlay;
