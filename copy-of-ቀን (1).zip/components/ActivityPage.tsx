
import React, { useState, useMemo } from 'react';
import { Calendar as CalendarIcon, History, TrendingUp, CheckCircle2, Circle, Flame, ArrowUpRight, ArrowDownRight, Filter, ChevronLeft, ChevronRight, Zap, Clock, Edit3 } from 'lucide-react';
import { Habit, CalendarEvent } from '../types';

interface ActivityPageProps {
  habits: Habit[];
  events: CalendarEvent[];
  onToggleHabit: (id: string) => void;
  onEditHabit: (habit: Habit) => void;
  onEditEvent: (event: CalendarEvent) => void;
}

type ActivitySubTab = 'today' | 'history' | 'insights';

const ActivityPage: React.FC<ActivityPageProps> = ({ habits, events, onToggleHabit, onEditHabit, onEditEvent }) => {
  const [subTab, setSubTab] = useState<ActivitySubTab>('today');
  const [selectedMonth, setSelectedMonth] = useState(new Date());

  const todayKey = new Date().toISOString().split('T')[0];

  const isScheduledForDate = (item: Habit | CalendarEvent, date: Date) => {
    const dateKey = date.toISOString().split('T')[0];
    
    if (item.startDate > dateKey) return false;
    if (item.endDate && item.endDate < dateKey) return false;

    if ('frequency' in item) {
      const day = date.getDay();
      const isWeekday = day >= 1 && day <= 5;
      const isWeekend = day === 0 || day === 6;
      if (item.frequency === 'daily') return true;
      if (item.frequency === 'weekdays' && isWeekday) return true;
      if (item.frequency === 'weekends' && isWeekend) return true;
      if (item.frequency === 'weekly' && new Date(item.createdAt).getDay() === day) return true;
      return false;
    } else {
      return item.startDate === dateKey || (item.endDate && item.startDate <= dateKey && item.endDate >= dateKey);
    }
  };

  const todayTasks = useMemo(() => {
    const scheduledHabits = habits.filter(h => !h.isPaused && isScheduledForDate(h, new Date()));
    const scheduledEvents = events.filter(e => isScheduledForDate(e, new Date()));
    return [
      ...scheduledHabits.map(h => ({ ...h, type: 'habit' })), 
      ...scheduledEvents.map(e => ({ ...e, type: 'event' }))
    ].sort((a, b) => a.startTime.localeCompare(b.startTime));
  }, [habits, events]);

  const stats = useMemo(() => {
    const totalToday = todayTasks.length;
    const completedToday = todayTasks.filter(t => t.type === 'habit' ? t.history[todayKey] : t.isCompleted).length;
    const rate = totalToday > 0 ? Math.round((completedToday / totalToday) * 100) : 0;
    const totalStreaks = habits.reduce((acc, h) => acc + (h.streak || 0), 0);
    return { rate, totalStreaks };
  }, [todayTasks, habits, todayKey]);

  const renderToday = () => (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="bg-white p-10 rounded-[56px] border border-gray-100 shadow-sm flex items-center justify-between">
        <div>
          <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-1">Activity Progress</p>
          <h3 className="text-4xl font-black text-gray-950 tracking-tighter">{todayTasks.length} Tasks</h3>
        </div>
        <div className="w-24 h-24 rounded-full border-[12px] border-indigo-50 flex items-center justify-center shadow-inner shadow-indigo-100">
          <span className="text-indigo-600 font-black text-2xl">{stats.rate}%</span>
        </div>
      </div>

      <div className="space-y-4">
        {todayTasks.length === 0 ? (
          <div className="text-center py-20 opacity-40">
            <CheckCircle2 className="w-16 h-16 mx-auto mb-4 text-green-400" />
            <p className="font-black uppercase tracking-widest text-xs">Everything is up to date</p>
          </div>
        ) : (
          todayTasks.map((task: any) => {
            const isDone = task.type === 'habit' ? task.history[todayKey] : task.isCompleted;
            return (
              <div 
                key={task.id}
                className={`p-7 rounded-[40px] border transition-all flex items-center justify-between ${
                  isDone ? 'bg-green-50/30 border-green-100 opacity-60' : 'bg-white border-gray-100 shadow-sm'
                }`}
              >
                <div className="flex items-center gap-5">
                  <button 
                    onClick={() => task.type === 'habit' && onToggleHabit(task.id)}
                    className={`w-14 h-14 rounded-[20px] flex items-center justify-center transition-all ${
                      isDone ? 'bg-green-500 text-white' : 'bg-gray-50 text-gray-300 hover:text-indigo-600 hover:bg-indigo-50'
                    }`}
                  >
                    {isDone ? <CheckCircle2 className="w-8 h-8" /> : <Circle className="w-8 h-8" />}
                  </button>
                  <div>
                    <h4 className={`font-black text-xl ${isDone ? 'line-through text-green-950' : 'text-gray-950'}`}>
                      {task.title}
                    </h4>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="text-[10px] font-black uppercase text-indigo-600 px-2 py-0.5 bg-indigo-50 rounded-full">
                        {task.type === 'habit' ? task.frequency : 'One-time'}
                      </span>
                      <span className="text-[11px] font-black text-gray-400 flex items-center gap-1">
                        <Clock className="w-3 h-3 text-indigo-300" />
                        {task.startTime}
                      </span>
                    </div>
                  </div>
                </div>
                <button 
                  onClick={() => task.type === 'habit' ? onEditHabit(task) : onEditEvent(task)}
                  className="p-3 text-gray-300 hover:text-indigo-600 hover:bg-indigo-50 rounded-2xl transition-all"
                >
                  <Edit3 className="w-6 h-6" />
                </button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );

  const renderHistory = () => {
    const year = selectedMonth.getFullYear();
    const month = selectedMonth.getMonth();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const days = Array.from({ length: daysInMonth }, (_, i) => new Date(year, month, i + 1));

    return (
      <div className="space-y-6 animate-in fade-in duration-300">
        <div className="flex items-center justify-between bg-white p-6 rounded-[32px] border border-gray-100 shadow-sm">
          <button onClick={() => setSelectedMonth(new Date(year, month - 1))} className="p-4 hover:bg-gray-50 rounded-[20px]"><ChevronLeft className="w-6 h-6"/></button>
          <span className="font-black text-gray-950 uppercase tracking-widest text-sm">{selectedMonth.toLocaleString('default', { month: 'long', year: 'numeric' })}</span>
          <button onClick={() => setSelectedMonth(new Date(year, month + 1))} className="p-4 hover:bg-gray-50 rounded-[20px]"><ChevronRight className="w-6 h-6"/></button>
        </div>

        <div className="grid grid-cols-7 gap-3">
          {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map(d => <div key={d} className="text-center text-[10px] font-black text-gray-300 p-2">{d}</div>)}
          {Array.from({ length: days[0].getDay() }).map((_, i) => <div key={`empty-${i}`} />)}
          {days.map(date => {
            const dateKey = date.toISOString().split('T')[0];
            const isToday = date.toDateString() === new Date().toDateString();
            
            const scheduledHabits = habits.filter(h => isScheduledForDate(h, date));
            const completed = scheduledHabits.filter(h => h.history[dateKey]).length;
            const hasActivity = scheduledHabits.length > 0;
            const fullSuccess = hasActivity && completed === scheduledHabits.length;
            const partialSuccess = hasActivity && completed > 0 && completed < scheduledHabits.length;

            return (
              <div 
                key={dateKey} 
                className={`aspect-square flex items-center justify-center rounded-[22px] text-xs font-black transition-all relative ${
                  isToday ? 'ring-4 ring-indigo-500/20 ring-offset-2' : ''
                } ${
                  fullSuccess ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-100 scale-110' : 
                  partialSuccess ? 'bg-amber-400 text-white shadow-xl shadow-amber-100' :
                  hasActivity ? 'bg-gray-100 text-gray-300' : 'bg-transparent text-gray-200'
                }`}
              >
                {date.getDate()}
              </div>
            );
          })}
        </div>

        <div className="bg-white p-10 rounded-[48px] border border-gray-100 space-y-8">
          <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest">Discipline Visualizer</h4>
          {habits.map(h => (
            <div key={h.id} className="space-y-3">
              <div className="flex justify-between items-end px-1">
                <span className="font-black text-gray-900">{h.title}</span>
                <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">{h.streak}d streak</span>
              </div>
              <div className="h-3 w-full bg-gray-50 rounded-full overflow-hidden flex gap-1 px-1">
                {days.map(d => {
                  const dk = d.toISOString().split('T')[0];
                  const sched = isScheduledForDate(h, d);
                  const done = h.history[dk];
                  return (
                    <div 
                      key={dk} 
                      className={`h-full flex-1 rounded-sm ${
                        sched ? (done ? 'bg-indigo-600' : 'bg-red-200') : 'bg-transparent'
                      }`}
                    />
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderInsights = () => {
    const bestHabit = [...habits].sort((a, b) => b.streak - a.streak)[0];
    return (
      <div className="space-y-6 animate-in fade-in duration-300">
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-indigo-600 p-10 rounded-[56px] text-white shadow-2xl shadow-indigo-100 flex flex-col justify-between h-56">
            <TrendingUp className="w-12 h-12 opacity-30" />
            <div>
              <p className="text-5xl font-black tracking-tighter">{stats.totalStreaks}</p>
              <p className="text-[10px] font-black uppercase tracking-widest opacity-60">Success Score</p>
            </div>
          </div>
          <div className="bg-white p-10 rounded-[56px] border border-gray-100 flex flex-col justify-between h-56 shadow-sm">
            <Flame className="w-12 h-12 text-amber-500 opacity-30" />
            <div>
              <p className="text-5xl font-black text-gray-950 tracking-tighter">{bestHabit?.streak || 0}</p>
              <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">Peak Discipline</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-12 rounded-[64px] border border-gray-100 space-y-10 shadow-sm">
          <h3 className="text-2xl font-black text-gray-950 tracking-tight">AI Insights</h3>
          <div className="space-y-8">
            <div className="flex items-center gap-8">
              <div className="w-20 h-20 rounded-[32px] bg-indigo-50 flex items-center justify-center text-indigo-500 shrink-0">
                <Clock className="w-10 h-10" />
              </div>
              <div>
                <p className="font-black text-gray-950 text-xl tracking-tight">Prime Performance</p>
                <p className="text-sm text-gray-400 font-medium">Your data suggests tasks scheduled before 10 AM have a 95% completion rate.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-12">
      <div className="flex items-center gap-2 bg-gray-100 p-1 rounded-[32px] w-fit mx-auto sticky top-20 z-10 shadow-2xl border-4 border-white">
        <button onClick={() => setSubTab('today')} className={`px-10 py-4 rounded-[28px] text-[10px] font-black uppercase tracking-widest transition-all ${subTab === 'today' ? 'bg-white text-indigo-600 shadow-xl' : 'text-gray-400 hover:text-gray-600'}`}>Today</button>
        <button onClick={() => setSubTab('history')} className={`px-10 py-4 rounded-[28px] text-[10px] font-black uppercase tracking-widest transition-all ${subTab === 'history' ? 'bg-white text-indigo-600 shadow-xl' : 'text-gray-400 hover:text-gray-600'}`}>History</button>
        <button onClick={() => setSubTab('insights')} className={`px-10 py-4 rounded-[28px] text-[10px] font-black uppercase tracking-widest transition-all ${subTab === 'insights' ? 'bg-white text-indigo-600 shadow-xl' : 'text-gray-400 hover:text-gray-600'}`}>Insights</button>
      </div>
      {subTab === 'today' && renderToday()}
      {subTab === 'history' && renderHistory()}
      {subTab === 'insights' && renderInsights()}
    </div>
  );
};

export default ActivityPage;
