
import React, { useState, useEffect } from 'react';
import { X, Zap, Clock, Bell, Volume2, BellOff, Infinity as InfinityIcon, CalendarDays } from 'lucide-react';
import { ExtractedHabitData, Habit, AlertMode, ReminderTime, Priority, Frequency } from '../types';
import ScrollDatePicker from './ScrollDatePicker';
import ScrollTimePicker from './ScrollTimePicker';

interface HabitConfirmationModalProps {
  habit: ExtractedHabitData & { alertMode?: AlertMode; reminderMinutes?: number; priority?: Priority };
  onConfirm: (habit: Habit) => void;
  onCancel: () => void;
  isEditing?: boolean;
}

const HabitConfirmationModal: React.FC<HabitConfirmationModalProps> = ({ habit, onConfirm, onCancel, isEditing = false }) => {
  const [title, setTitle] = useState(habit.title);
  const [startDate, setStartDate] = useState(habit.startDate);
  const [startTime, setStartTime] = useState(habit.startTime || "09:00");
  const [hasEndDate, setHasEndDate] = useState(!!habit.endDate);
  const [endDate, setEndDate] = useState(habit.endDate || '');
  const [duration, setDuration] = useState(habit.durationMinutes);
  const [frequency, setFrequency] = useState<Frequency>(habit.frequency);
  const [alertMode, setAlertMode] = useState<AlertMode>(habit.alertMode || AlertMode.SILENT);

  const isEveryDay = frequency === 'daily';

  useEffect(() => {
    if (alertMode !== AlertMode.SILENT && (!startTime || startTime === "09:00")) {
      const now = new Date();
      if (startDate === now.toISOString().split('T')[0] && now.getHours() >= 9) {
        const nextHour = (now.getHours() + 1) % 24;
        setStartTime(`${nextHour.toString().padStart(2, '0')}:00`);
      } else {
        setStartTime("09:00");
      }
    }
  }, [alertMode, startDate]);

  const handleConfirm = () => {
    onConfirm({
      id: '',
      title,
      frequency,
      startDate,
      startTime,
      endDate: hasEndDate && endDate ? endDate : undefined,
      durationMinutes: duration,
      priority: Priority.NORMAL,
      alertMode,
      reminderMinutes: 10,
      createdAt: (habit as any).createdAt || new Date().toISOString(),
      history: (habit as any).history || {},
      streak: (habit as any).streak || 0,
      isPaused: (habit as any).isPaused || false
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4 bg-black/60 backdrop-blur-md">
      <div className="bg-white w-full max-w-md rounded-[64px] shadow-[0_35px_60px_-15px_rgba(0,0,0,0.4)] overflow-hidden animate-in fade-in zoom-in duration-300 border-[10px] border-amber-50">
        <div className="p-10 space-y-8 max-h-[85vh] overflow-y-auto no-scrollbar">
          <div className="flex items-center justify-between">
            <div className="bg-amber-100 p-5 rounded-[28px] animate-pulse">
              <Zap className="w-8 h-8 text-amber-600" />
            </div>
            <button onClick={onCancel} className="bg-gray-100 p-3 rounded-full text-gray-400 hover:text-gray-500 transition-all hover:rotate-90"><X /></button>
          </div>

          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-3xl font-black text-gray-950 uppercase tracking-tighter">
                {isEveryDay ? 'Every Day Task' : 'Recurring habit'}
              </h3>
              {isEveryDay && (
                <span className="bg-amber-50 text-amber-600 text-[10px] font-black uppercase px-3 py-1 rounded-full animate-bounce">
                  No date selection needed
                </span>
              )}
            </div>
            
            <div className="space-y-1">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">Commitment</label>
              <input 
                value={title} 
                onChange={(e) => setTitle(e.target.value)}
                className="w-full text-2xl font-black bg-gray-50 border-none rounded-[32px] p-6 focus:ring-4 focus:ring-amber-100 outline-none transition-all"
              />
            </div>

            <div className="space-y-4">
               <div className="flex items-center justify-between px-2">
                 <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Starting point</p>
                 <button 
                  onClick={() => setHasEndDate(!hasEndDate)}
                  className={`flex items-center gap-1 text-[10px] font-black uppercase px-3 py-1 rounded-full transition-all ${hasEndDate ? 'bg-amber-100 text-amber-700' : 'bg-green-100 text-green-700'}`}
                 >
                   {hasEndDate ? <CalendarDays className="w-3 h-3" /> : <InfinityIcon className="w-3 h-3" />}
                   {hasEndDate ? 'Ends on date' : 'Repeats Forever'}
                 </button>
               </div>

               <div className={`${isEveryDay ? 'opacity-50 grayscale scale-95 pointer-events-none' : ''} transition-all`}>
                 <ScrollDatePicker 
                   label={isEveryDay ? "Starts Today (Auto)" : "Starts On"} 
                   selectedDate={startDate} 
                   onSelect={setStartDate} 
                 />
               </div>

               {hasEndDate && (
                 <div className="animate-in slide-in-from-top-2 duration-300">
                   <ScrollDatePicker 
                     label="Ending On" 
                     selectedDate={endDate || startDate} 
                     onSelect={setEndDate} 
                   />
                 </div>
               )}
            </div>

            <div className="space-y-4 pt-4 border-t border-gray-50">
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">Remind Strategy</p>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { mode: AlertMode.SILENT, icon: <BellOff />, label: "Silent" },
                  { mode: AlertMode.NORMAL, icon: <Bell />, label: "Notify" },
                  { mode: AlertMode.ALARM, icon: <Volume2 />, label: "Alarm" },
                ].map(({ mode, icon, label }) => (
                  <button
                    key={mode}
                    onClick={() => setAlertMode(mode)}
                    className={`flex flex-col items-center justify-center gap-2 py-6 rounded-[32px] border-2 transition-all ${
                      alertMode === mode 
                        ? 'border-amber-500 bg-amber-50 text-amber-700 font-black shadow-lg shadow-amber-100 scale-105' 
                        : 'border-gray-50 bg-gray-50 text-gray-400 opacity-60'
                    }`}
                  >
                    {React.cloneElement(icon as React.ReactElement, { className: 'w-6 h-6' })}
                    <span className="text-[10px] uppercase font-black tracking-widest">{label}</span>
                  </button>
                ))}
              </div>
            </div>

            {alertMode !== AlertMode.SILENT && (
              <div className="animate-in slide-in-from-top-4 duration-500">
                <ScrollTimePicker 
                  label="Daily Schedule" 
                  time={startTime} 
                  onChange={setStartTime} 
                />
              </div>
            )}
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 p-7 rounded-[32px] space-y-1">
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Frequency</p>
                <select 
                  value={frequency} 
                  onChange={(e) => setFrequency(e.target.value as Frequency)}
                  className="bg-transparent border-none font-black text-xl text-gray-950 outline-none w-full"
                >
                  <option value="daily">Every Day</option>
                  <option value="weekdays">Weekdays</option>
                  <option value="weekends">Weekends</option>
                  <option value="weekly">Weekly</option>
                </select>
              </div>
              <div className="bg-gray-50 p-7 rounded-[32px] space-y-1">
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Mins</p>
                <input 
                  type="number" 
                  value={duration} 
                  onChange={(e) => setDuration(parseInt(e.target.value))}
                  className="bg-transparent border-none font-black text-xl text-gray-950 outline-none w-full"
                />
              </div>
            </div>
          </div>

          <div className="flex gap-4 pt-8 border-t border-gray-100">
            <button onClick={onCancel} className="flex-1 py-6 font-black text-gray-400 hover:text-gray-600 uppercase tracking-widest text-xs transition-colors">Dismiss</button>
            <button onClick={handleConfirm} className="flex-[2] py-6 bg-gray-950 text-white rounded-[32px] font-black shadow-2xl hover:bg-black active:scale-95 transition-all uppercase tracking-widest text-sm">
              {isEditing ? 'Confirm Changes' : 'Start Now'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HabitConfirmationModal;
