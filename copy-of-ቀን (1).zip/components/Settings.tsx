
import React, { useState } from 'react';
import { Settings as SettingsIcon, Bell, Shield, Info, Database, LogOut, KeyRound, Copy, Check, Share2 } from 'lucide-react';

interface SettingsProps {
  dismissalPhrase: string;
  setDismissalPhrase: (phrase: string) => void;
  onWipeData: () => void;
}

const Settings: React.FC<SettingsProps> = ({ dismissalPhrase, setDismissalPhrase, onWipeData }) => {
  const [copied, setCopied] = useState(false);

  const copyUrl = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'ቀን Calendar',
          text: 'Check out my AI-powered calendar!',
          url: window.location.href,
        });
      } catch (err) {
        console.log('Share failed:', err);
      }
    } else {
      copyUrl();
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      <div className="text-center py-8">
        <div className="w-20 h-20 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <SettingsIcon className="w-10 h-10 text-indigo-600" />
        </div>
        <h2 className="text-2xl font-black text-gray-800">App Settings</h2>
        <p className="text-gray-400 font-medium">Manage your preferences and data</p>
      </div>

      <div className="bg-white rounded-[32px] border border-gray-100 shadow-sm overflow-hidden">
        <div className="p-6 border-b">
          <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest mb-4 flex items-center gap-2">
            <Share2 className="w-4 h-4" />
            Install on Phone
          </h3>
          <div className="space-y-4">
            <p className="text-xs text-gray-500 leading-relaxed">
              To install this as an app, copy the link below and paste it into <strong>Safari</strong> on iPhone or <strong>Chrome</strong> on Android.
            </p>
            <button 
              onClick={handleShare}
              className={`w-full flex items-center justify-between p-4 rounded-2xl border-2 transition-all ${
                copied ? 'border-green-500 bg-green-50' : 'border-indigo-50 bg-gray-50'
              }`}
            >
              <span className="text-xs font-bold text-gray-600 truncate mr-4">
                {window.location.href}
              </span>
              {copied ? (
                <Check className="w-5 h-5 text-green-600 shrink-0" />
              ) : (
                <Copy className="w-5 h-5 text-indigo-600 shrink-0" />
              )}
            </button>
          </div>
        </div>

        <div className="p-6 border-b">
          <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest mb-4 flex items-center gap-2">
            <KeyRound className="w-4 h-4" />
            Alarm Accountability
          </h3>
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-500">Global Dismissal Phrase</label>
            <input 
              value={dismissalPhrase}
              onChange={(e) => setDismissalPhrase(e.target.value)}
              placeholder="e.g. I did it"
              className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 font-bold text-gray-800 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            />
            <p className="text-[10px] text-gray-400 italic mt-1">
              * This phrase must be typed exactly to silence loud alarms.
            </p>
          </div>
        </div>

        <div className="divide-y divide-gray-50">
          <SettingsRow icon={<Bell />} label="Notification Permissions" status="Enabled" />
          <SettingsRow icon={<Shield />} label="Data Encryption" status="Active" />
          <SettingsRow icon={<Database />} label="Cloud Sync" status="Off" />
          <SettingsRow icon={<Info />} label="App Version" status="2.6.0-PWA" />
        </div>
      </div>

      <button 
        onClick={onWipeData}
        className="w-full py-5 bg-red-50 text-red-600 rounded-3xl font-bold flex items-center justify-center gap-2 hover:bg-red-100 transition-all active:scale-95"
      >
        <LogOut className="w-5 h-5" />
        Wipe All Data
      </button>
    </div>
  );
};

const SettingsRow = ({ icon, label, status }: any) => (
  <div className="flex items-center justify-between p-6 hover:bg-gray-50 transition-colors">
    <div className="flex items-center gap-4">
      <div className="text-gray-400">{React.cloneElement(icon, { className: 'w-5 h-5' })}</div>
      <span className="font-bold text-gray-700">{label}</span>
    </div>
    <span className="text-xs font-black uppercase tracking-widest text-indigo-500 bg-indigo-50 px-3 py-1 rounded-full">{status}</span>
  </div>
);

export default Settings;
