
import React, { useMemo } from 'react';
import { CalendarEvent, CalendarViewType, AlertMode } from '../types';
import { Trash2, MapPin, Clock, Bell, Volume2, Edit3, Calendar as CalendarIcon, BellOff, ChevronRight } from 'lucide-react';

interface CalendarProps {
  view: CalendarViewType;
  setView: (view: CalendarViewType) => void;
  events: CalendarEvent[];
  onDelete: (id: string) => void;
  onEdit: (event: CalendarEvent) => void;
}

const Calendar: React.FC<CalendarProps> = ({ view, setView, events, onDelete, onEdit }) => {
  const todayKey = new Date().toISOString().split('T')[0];

  const filteredEvents = useMemo(() => {
    const sorted = [...events].sort((a, b) => {
      const dateCompare = a.startDate.localeCompare(b.startDate);
      if (dateCompare !== 0) return dateCompare;
      return a.startTime.localeCompare(b.startTime);
    });

    const now = new Date();
    
    if (view === 'day') {
      return sorted.filter(e => e.startDate === todayKey);
    }
    
    if (view === 'week') {
      const weekEnd = new Date();
      weekEnd.setDate(now.getDate() + 7);
      const weekEndKey = weekEnd.toISOString().split('T')[0];
      return sorted.filter(e => e.startDate >= todayKey && e.startDate <= weekEndKey);
    }

    // Month View (Show all for current month context)
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
    const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().split('T')[0];
    return sorted.filter(e => e.startDate >= monthStart && e.startDate <= monthEnd);
  }, [events, view, todayKey]);

  return (
    <div className="w-full space-y-6">
      {/* View Switcher Segmented Control */}
      <div className="flex p-1 bg-white rounded-[32px] border border-gray-100 shadow-sm w-full max-w-sm mx-auto sticky top-20 z-10">
        {(['day', 'week', 'month'] as CalendarViewType[]).map((v) => (
          <button
            key={v}
            onClick={() => setView(v)}
            className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest rounded-[28px] transition-all ${
              view === v 
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' 
                : 'text-gray-400 hover:text-gray-600'
            }`}
          >
            {v}
          </button>
        ))}
      </div>

      <div className="space-y-4">
        {filteredEvents.length === 0 ? (
          <div className="p-20 text-center bg-white rounded-[48px] border border-gray-100 shadow-sm animate-in fade-in duration-500">
            <div className="bg-indigo-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
              <CalendarIcon className="w-10 h-10 text-indigo-200" />
            </div>
            <p className="text-gray-400 font-black uppercase tracking-widest text-[10px]">
              No events for this {view}
            </p>
          </div>
        ) : (
          filteredEvents.map((event) => {
            const date = new Date(event.startDate + 'T12:00:00');
            const isToday = todayKey === event.startDate;
            
            return (
              <div 
                key={event.id} 
                className={`bg-white p-8 rounded-[40px] border border-gray-100 flex items-center gap-6 transition-all hover:shadow-xl hover:shadow-indigo-50/20 animate-in slide-in-from-bottom-2 ${
                  event.isCompleted ? 'opacity-40 grayscale scale-95' : ''
                }`}
              >
                <div className={`w-16 h-16 rounded-[24px] flex flex-col items-center justify-center shrink-0 border-4 transition-colors ${
                  isToday ? 'bg-indigo-600 border-indigo-100 text-white' : 'bg-gray-50 border-white text-gray-700'
                }`}>
                  <span className="text-[10px] font-black uppercase leading-tight">
                    {date.toLocaleDateString(undefined, { month: 'short' })}
                  </span>
                  <span className="text-2xl font-black leading-none">{date.getDate()}</span>
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between">
                    <div className="truncate">
                      <h3 className="font-black text-xl text-gray-900 flex items-center gap-2 truncate tracking-tight">
                        {event.title}
                        {event.alertMode === AlertMode.ALARM && <Volume2 className="w-4 h-4 text-red-500 shrink-0" />}
                        {event.alertMode === AlertMode.NORMAL && <Bell className="w-4 h-4 text-indigo-400 shrink-0" />}
                        {event.alertMode === AlertMode.SILENT && <BellOff className="w-4 h-4 text-gray-300 shrink-0" />}
                      </h3>
                      <div className="flex flex-wrap gap-x-4 gap-y-1 mt-1 text-[11px] text-gray-400 font-bold uppercase tracking-wider">
                        <span className="flex items-center gap-1 text-indigo-600">
                          <Clock className="w-3 h-3" />
                          {event.startTime}
                        </span>
                        {event.location && (
                          <span className="flex items-center gap-1 truncate max-w-[150px]">
                            <MapPin className="w-3 h-3" />
                            {event.location}
                          </span>
                        )}
                        <span>{event.durationMinutes}m</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button 
                        onClick={() => onEdit(event)}
                        className="p-3 text-gray-300 hover:text-indigo-600 hover:bg-indigo-50 rounded-2xl transition-all"
                      >
                        <Edit3 className="w-5 h-5" />
                      </button>
                      <button 
                        onClick={() => onDelete(event.id)}
                        className="p-3 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-2xl transition-all"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default Calendar;
