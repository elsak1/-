
import React, { useState, useEffect } from 'react';
import { X, Calendar, Clock, MapPin, Bell, Volume2, BellOff } from 'lucide-react';
import { ExtractedEventData, CalendarEvent, AlertMode, ReminderTime } from '../types';
import ScrollDatePicker from './ScrollDatePicker';
import ScrollTimePicker from './ScrollTimePicker';

interface ConfirmationModalProps {
  event: ExtractedEventData & { alertMode?: AlertMode; reminderMinutes?: number };
  onConfirm: (event: CalendarEvent) => void;
  onCancel: () => void;
  isEditing?: boolean;
}

const ConfirmationModal: React.FC<ConfirmationModalProps> = ({ event, onConfirm, onCancel, isEditing = false }) => {
  const [title, setTitle] = useState(event.title);
  const [startDate, setStartDate] = useState(event.startDate);
  const [startTime, setStartTime] = useState(event.startTime || "09:00");
  const [duration, setDuration] = useState(event.durationMinutes);
  const [location, setLocation] = useState(event.location);
  const [alertMode, setAlertMode] = useState<AlertMode>(event.alertMode || AlertMode.SILENT);
  const [reminder, setReminder] = useState<ReminderTime>(event.reminderMinutes || ReminderTime.MIN_10);

  // Default time logic: If alert enabled but no time, pick 9:00 AM or next available hour
  useEffect(() => {
    if (alertMode !== AlertMode.SILENT && (!startTime || startTime === "09:00")) {
      const now = new Date();
      const currentHour = now.getHours();
      // If it's already past 9 AM today, and it's for today, set next hour. Otherwise default 9 AM.
      if (startDate === now.toISOString().split('T')[0] && currentHour >= 9) {
        const nextHour = (currentHour + 1) % 24;
        setStartTime(`${nextHour.toString().padStart(2, '0')}:00`);
      } else {
        setStartTime("09:00");
      }
    }
  }, [alertMode]);

  const handleConfirm = () => {
    onConfirm({
      id: '',
      title,
      startTime,
      startDate,
      endDate: event.endDate || undefined,
      durationMinutes: duration,
      location,
      description: event.description,
      alertMode,
      reminderMinutes: reminder,
      isCompleted: false
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4 bg-black/60 backdrop-blur-md">
      <div className="bg-white w-full max-w-lg rounded-[56px] shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-300 border-[10px] border-indigo-50">
        <div className="px-10 py-8 flex items-center justify-between">
          <h3 className="text-3xl font-black text-indigo-950 uppercase tracking-tighter">Event Review</h3>
          <button onClick={onCancel} className="bg-gray-100 p-3 rounded-full text-gray-400 hover:text-gray-600 transition-all hover:rotate-90">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="px-10 pb-10 space-y-8 max-h-[70vh] overflow-y-auto no-scrollbar">
          <div className="space-y-6">
            <div className="space-y-1">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">Description</label>
              <input 
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full text-2xl font-black bg-gray-50 border-none rounded-[32px] p-6 outline-none focus:ring-4 focus:ring-indigo-100 transition-all"
              />
            </div>

            <ScrollDatePicker 
              label="Selected Date" 
              selectedDate={startDate} 
              onSelect={setStartDate} 
            />

            <div className="space-y-4 pt-4 border-t border-gray-50">
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">Alert Mode</p>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { mode: AlertMode.SILENT, icon: <BellOff />, label: "Silent" },
                  { mode: AlertMode.NORMAL, icon: <Bell />, label: "Notify" },
                  { mode: AlertMode.ALARM, icon: <Volume2 />, label: "Alarm" },
                ].map(({ mode, icon, label }) => (
                  <button
                    key={mode}
                    onClick={() => setAlertMode(mode)}
                    className={`flex flex-col items-center justify-center gap-2 py-6 rounded-[32px] border-2 transition-all ${
                      alertMode === mode 
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-700 font-black shadow-lg shadow-indigo-100 scale-105' 
                        : 'border-gray-50 bg-gray-50 text-gray-400 opacity-60'
                    }`}
                  >
                    {React.cloneElement(icon as React.ReactElement, { className: 'w-6 h-6' })}
                    <span className="text-[10px] uppercase font-black tracking-widest">{label}</span>
                  </button>
                ))}
              </div>
            </div>

            {alertMode !== AlertMode.SILENT && (
              <div className="animate-in slide-in-from-top-4 duration-500">
                <ScrollTimePicker 
                  label="Remind At" 
                  time={startTime} 
                  onChange={setStartTime} 
                />
              </div>
            )}

            <div className="grid grid-cols-2 gap-6 pt-4 border-t border-gray-50">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">Duration (m)</label>
                <div className="relative">
                  <Clock className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input 
                    type="number"
                    value={duration}
                    onChange={(e) => setDuration(parseInt(e.target.value) || 0)}
                    className="w-full text-xl font-black bg-gray-50 border-none rounded-[24px] p-5 pl-14 outline-none focus:ring-4 focus:ring-indigo-100"
                  />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">Where</label>
                <div className="relative">
                  <MapPin className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input 
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="None"
                    className="w-full text-xl font-black bg-gray-50 border-none rounded-[24px] p-5 pl-14 outline-none focus:ring-4 focus:ring-indigo-100"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="p-10 bg-gray-50 flex gap-4">
          <button 
            onClick={onCancel}
            className="flex-1 py-6 font-black uppercase tracking-widest text-xs text-gray-400 hover:text-gray-600 transition-colors"
          >
            Cancel
          </button>
          <button 
            onClick={handleConfirm}
            className="flex-[2] py-6 bg-indigo-600 text-white rounded-[32px] font-black uppercase tracking-widest text-sm shadow-2xl shadow-indigo-200 hover:bg-indigo-700 active:scale-95 transition-all"
          >
            {isEditing ? 'Save Entry' : 'Schedule'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationModal;
