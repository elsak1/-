
import { GoogleGenAI, Type } from "@google/genai";
import { ExtractedEventData, ExtractedHabitData } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function parseEventFromText(text: string): Promise<ExtractedEventData | null> {
  const now = new Date();
  const todayStr = now.toLocaleDateString('en-US', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric'
  });

  const prompt = `
    Extract calendar event information from the following text.
    Extract 'startTime' in HH:mm format (24-hour). If not mentioned, return "09:00".
    Current date for context: ${todayStr}.
    Always extract 'startDate' (YYYY-MM-DD). If not mentioned, use today's date.
    Extract 'endDate' (YYYY-MM-DD) if a range or 'until' is mentioned.
    If the user mentions "every day" or "each day", the frequency is daily.
    Text: "${text}"
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            startTime: { type: Type.STRING, description: "HH:mm format" },
            startDate: { type: Type.STRING, description: "Format YYYY-MM-DD" },
            endDate: { type: Type.STRING, description: "Format YYYY-MM-DD" },
            durationMinutes: { type: Type.INTEGER },
            location: { type: Type.STRING },
            description: { type: Type.STRING },
            frequency: { type: Type.STRING, enum: ['daily', 'weekly', 'weekdays', 'weekends', 'none'] }
          },
          required: ["title", "durationMinutes", "startDate", "startTime"]
        }
      }
    });

    const result = JSON.parse(response.text || '{}');
    return {
      title: result.title || "New Event",
      startTime: result.startTime || "09:00",
      startDate: result.startDate || now.toISOString().split('T')[0],
      endDate: result.endDate || undefined,
      durationMinutes: result.durationMinutes || 60,
      location: result.location || "",
      description: result.description || "",
      frequency: result.frequency === 'none' ? undefined : result.frequency
    } as any;
  } catch (error) {
    console.error("Error parsing event text:", error);
    return null;
  }
}

export async function parseHabitFromText(text: string): Promise<ExtractedHabitData | null> {
  const now = new Date();
  const prompt = `
    Extract habit or daily activity information from the following text.
    Extract 'startTime' in HH:mm format (24-hour). If not mentioned, return "09:00".
    Frequency must be one of: 'daily', 'weekly', 'weekdays', 'weekends'.
    User phrases like "every day", "each day", "everyday" or "daily" must map to 'daily'.
    Always extract 'startDate' (YYYY-MM-DD). If not mentioned, use today's date.
    Extract 'endDate' (YYYY-MM-DD) if mentioned. If "forever" or no end is mentioned, leave it out.
    Text: "${text}"
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            frequency: { type: Type.STRING, enum: ['daily', 'weekly', 'weekdays', 'weekends'] },
            startTime: { type: Type.STRING, description: "HH:mm format" },
            startDate: { type: Type.STRING, description: "Format YYYY-MM-DD" },
            endDate: { type: Type.STRING, description: "Format YYYY-MM-DD" },
            durationMinutes: { type: Type.INTEGER }
          },
          required: ["title", "frequency", "startDate", "startTime"]
        }
      }
    });

    const result = JSON.parse(response.text || '{}');
    return {
      title: result.title || "New Activity",
      frequency: result.frequency || "daily",
      startTime: result.startTime || "09:00",
      startDate: result.startDate || now.toISOString().split('T')[0],
      endDate: result.endDate || undefined,
      durationMinutes: result.durationMinutes || 15
    };
  } catch (error) {
    console.error("Error parsing habit text:", error);
    return null;
  }
}
